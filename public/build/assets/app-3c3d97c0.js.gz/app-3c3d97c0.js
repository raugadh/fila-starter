import{a as o}from"./axios-28bc18a3.js";window.axios=o;window.axios.defaults.headers.common["X-Requested-With"]="XMLHttpRequest";
